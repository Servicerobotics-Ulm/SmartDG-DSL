/*****************************************
www.servicerobotik-ulm.de
Smart Dependency Graph (SmartDG)
Vineet.Nagrath@thu.de
SmartDGlite Auto Generated 
*****************************************/
var cy = cytoscape({
  container: document.getElementById('cy'),
  boxSelectionEnabled: false,

  style: cytoscape.stylesheet()
    .selector('node')
      .css({
        'width': '50px',
        'height': '50px',
        'content': 'data(LAB)',
        'pie-size': '98%',
        'pie-1-background-color': '#FF0000',
        'pie-1-background-size': 'mapData(False, 0, 10, 0, 100)',
        'pie-2-background-color': '#00FF00',
        'pie-2-background-size': 'mapData(True, 0, 10, 0, 100)',
      })
    .selector('parent')
      .css({
        'content': 'data(LAB)',
        'text-valign': 'top',
        'text-halign': 'center',
      })
    .selector('edge')
      .css({
        'content': 'data(LAB)',
        'curve-style': 'segments',
        'width': 2,
        'target-arrow-shape': 'triangle',
        'opacity': 1.0
      })
    .selector(':selected')
      .css({
        'background-color': 'black',
        'line-color': 'black',
        'target-arrow-color': 'black',
        'source-arrow-color': 'black',
        'opacity': 1
      })
    .selector('.faded')
      .css({
        'opacity': 0.25,
        'text-opacity': 0
      }),

  elements: {
    nodes: [
      { data: { id: 'BLINKY' , LAB: 'Live', True: 0, False: 0   }, position: { x: 50, y: 50 } },
      { data: { id: 'A1' , LAB: 'Node A1' } },
      { data: { id: 'A1xInxA_In', LAB: 'Port A_In', parent: 'A1' } },
      { data: { id: 'A1xInxA_InxOverHeat', LAB: 'Object OverHeat', parent: 'A1xInxA_In' } },
      { data: { id: 'A1xInxA_InxOverHeatxAllx', LAB: 'All', parent: 'A1xInxA_InxOverHeat', True: 0, False: 0  }, position: { x: 600, y: 250 } },
      { data: { id: 'A1xInxA_InxPrivacy', LAB: 'Object Privacy', parent: 'A1xInxA_In' } },
      { data: { id: 'A1xInxA_InxPrivacyxAllx', LAB: 'All', parent: 'A1xInxA_InxPrivacy', True: 0, False: 0  }, position: { x: 600, y: 400 } },
      { data: { id: 'A1xOutxA_Out', LAB: 'Port A_Out', parent: 'A1' } },
      { data: { id: 'A1xOutxA_OutxOverHeat', LAB: 'Object OverHeat', parent: 'A1xOutxA_Out' } },
      { data: { id: 'A1xOutxA_OutxOverHeatxAllx', LAB: 'All', parent: 'A1xOutxA_OutxOverHeat', True: 0, False: 0  }, position: { x: 1100, y: 250 } },
      { data: { id: 'A1xOutxA_OutxOverHeatxB1xInxB_InxOverHeatx', LAB: 'To B1.In.B_In.OverHeat', parent: 'A1xOutxA_OutxOverHeat', True: 0, False: 0  }, position: { x: 1100, y: 400 } },
      { data: { id: 'A1xOutxA_OutxPrivacy', LAB: 'Object Privacy', parent: 'A1xOutxA_Out' } },
      { data: { id: 'A1xOutxA_OutxPrivacyxAllx', LAB: 'All', parent: 'A1xOutxA_OutxPrivacy', True: 0, False: 0  }, position: { x: 1100, y: 550 } },
      { data: { id: 'A1xOutxA_OutxPrivacyxB1xInxB_InxPrivacyx', LAB: 'To B1.In.B_In.Privacy', parent: 'A1xOutxA_OutxPrivacy', True: 0, False: 0  }, position: { x: 1100, y: 700 } },
      { data: { id: 'A2' , LAB: 'Node A2' } },
      { data: { id: 'A2xInxA_In', LAB: 'Port A_In', parent: 'A2' } },
      { data: { id: 'A2xInxA_InxOverHeat', LAB: 'Object OverHeat', parent: 'A2xInxA_In' } },
      { data: { id: 'A2xInxA_InxOverHeatxAllx', LAB: 'All', parent: 'A2xInxA_InxOverHeat', True: 0, False: 0  }, position: { x: 600, y: 1250 } },
      { data: { id: 'A2xInxA_InxOverHeatxB1xOutxB_OutxOverHeatx', LAB: 'From B1.Out.B_Out.OverHeat', parent: 'A2xInxA_InxOverHeat', True: 0, False: 0  }, position: { x: 600, y: 1400 } },
      { data: { id: 'A2xInxA_InxPrivacy', LAB: 'Object Privacy', parent: 'A2xInxA_In' } },
      { data: { id: 'A2xInxA_InxPrivacyxAllx', LAB: 'All', parent: 'A2xInxA_InxPrivacy', True: 0, False: 0  }, position: { x: 600, y: 1550 } },
      { data: { id: 'A2xInxA_InxPrivacyxB1xOutxB_OutxPrivacyx', LAB: 'From B1.Out.B_Out.Privacy', parent: 'A2xInxA_InxPrivacy', True: 0, False: 0  }, position: { x: 600, y: 1700 } },
      { data: { id: 'A2xOutxA_Out', LAB: 'Port A_Out', parent: 'A2' } },
      { data: { id: 'A2xOutxA_OutxOverHeat', LAB: 'Object OverHeat', parent: 'A2xOutxA_Out' } },
      { data: { id: 'A2xOutxA_OutxOverHeatxAllx', LAB: 'All', parent: 'A2xOutxA_OutxOverHeat', True: 0, False: 0  }, position: { x: 1100, y: 1250 } },
      { data: { id: 'A2xOutxA_OutxPrivacy', LAB: 'Object Privacy', parent: 'A2xOutxA_Out' } },
      { data: { id: 'A2xOutxA_OutxPrivacyxAllx', LAB: 'All', parent: 'A2xOutxA_OutxPrivacy', True: 0, False: 0  }, position: { x: 1100, y: 1400 } },
      { data: { id: 'B1' , LAB: 'Node B1' } },
      { data: { id: 'B1xInxB_In', LAB: 'Port B_In', parent: 'B1' } },
      { data: { id: 'B1xInxB_InxOverHeat', LAB: 'Object OverHeat', parent: 'B1xInxB_In' } },
      { data: { id: 'B1xInxB_InxOverHeatxAllx', LAB: 'All', parent: 'B1xInxB_InxOverHeat', True: 0, False: 0  }, position: { x: 600, y: 2650 } },
      { data: { id: 'B1xInxB_InxOverHeatxA1xOutxA_OutxOverHeatx', LAB: 'From A1.Out.A_Out.OverHeat', parent: 'B1xInxB_InxOverHeat', True: 0, False: 0  }, position: { x: 600, y: 2800 } },
      { data: { id: 'B1xInxB_InxPrivacy', LAB: 'Object Privacy', parent: 'B1xInxB_In' } },
      { data: { id: 'B1xInxB_InxPrivacyxAllx', LAB: 'All', parent: 'B1xInxB_InxPrivacy', True: 0, False: 0  }, position: { x: 600, y: 2950 } },
      { data: { id: 'B1xInxB_InxPrivacyxA1xOutxA_OutxPrivacyx', LAB: 'From A1.Out.A_Out.Privacy', parent: 'B1xInxB_InxPrivacy', True: 0, False: 0  }, position: { x: 600, y: 3100 } },
      { data: { id: 'B1xOutxB_Out', LAB: 'Port B_Out', parent: 'B1' } },
      { data: { id: 'B1xOutxB_OutxOverHeat', LAB: 'Object OverHeat', parent: 'B1xOutxB_Out' } },
      { data: { id: 'B1xOutxB_OutxOverHeatxAllx', LAB: 'All', parent: 'B1xOutxB_OutxOverHeat', True: 0, False: 0  }, position: { x: 1100, y: 2650 } },
      { data: { id: 'B1xOutxB_OutxOverHeatxA2xInxA_InxOverHeatx', LAB: 'To A2.In.A_In.OverHeat', parent: 'B1xOutxB_OutxOverHeat', True: 0, False: 0  }, position: { x: 1100, y: 2800 } },
      { data: { id: 'B1xOutxB_OutxPrivacy', LAB: 'Object Privacy', parent: 'B1xOutxB_Out' } },
      { data: { id: 'B1xOutxB_OutxPrivacyxAllx', LAB: 'All', parent: 'B1xOutxB_OutxPrivacy', True: 0, False: 0  }, position: { x: 1100, y: 2950 } },
      { data: { id: 'B1xOutxB_OutxPrivacyxA2xInxA_InxPrivacyx', LAB: 'To A2.In.A_In.Privacy', parent: 'B1xOutxB_OutxPrivacy', True: 0, False: 0  }, position: { x: 1100, y: 3100 } },
    ],

    edges: [
      { data: { id: 'A1xOutxA_OutxPrivacyxxxB1xInxB_InxPrivacy', LAB: 'CS05', weight: 1, source: 'A1xOutxA_OutxPrivacyxB1xInxB_InxPrivacyx', target: 'B1xInxB_InxPrivacyxA1xOutxA_OutxPrivacyx' } },
      { data: { id: 'B1xOutxB_OutxPrivacyxxxA2xInxA_InxPrivacy', LAB: 'Unnamed', weight: 1, source: 'B1xOutxB_OutxPrivacyxA2xInxA_InxPrivacyx', target: 'A2xInxA_InxPrivacyxB1xOutxB_OutxPrivacyx' } },
      { data: { id: 'A1xOutxA_OutxOverHeatxxxB1xInxB_InxOverHeat', LAB: 'Unnamed', weight: 1, source: 'A1xOutxA_OutxOverHeatxB1xInxB_InxOverHeatx', target: 'B1xInxB_InxOverHeatxA1xOutxA_OutxOverHeatx' } },
      { data: { id: 'B1xOutxB_OutxOverHeatxxxA2xInxA_InxOverHeat', LAB: 'Unnamed', weight: 1, source: 'B1xOutxB_OutxOverHeatxA2xInxA_InxOverHeatx', target: 'A2xInxA_InxOverHeatxB1xOutxB_OutxOverHeatx' } },
    ]
  },

  layout: {
    name: 'preset',
    padding: 5
  },

  ready: function(){
    window.cy = this;
  }
});

function ViewDG(){
  $.getScript( "http://localhost:3000/DGlite.json", function( data, textStatus, jqxhr ) {
  for(var i=0; i< dgdata.length; i++){
    if(dgdata[i].val == "NA")     {  cy.$(dgdata[i].id).data('False', 0); cy.$(dgdata[i].id).data('True', 0); }
    else if(dgdata[i].val == "T")     {  cy.$(dgdata[i].id).data('False', 0); cy.$(dgdata[i].id).data('True', 10); }
    else if(dgdata[i].val == "F"){  cy.$(dgdata[i].id).data('False', 10); cy.$(dgdata[i].id).data('True', 0); }
    else {  cy.$(dgdata[i].id).data('False', 10-dgdata[i].val); cy.$(dgdata[i].id).data('True', 1+dgdata[i].val-1); }
  }	
  });
}
