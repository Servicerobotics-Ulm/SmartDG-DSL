browser-sync start --server --directory --files '**/*'
