/*****************************************
www.servicerobotik-ulm.de
Smart Dependency Graph (SmartDG)
Vineet.Nagrath@thu.de
SmartDGlite Auto Generated 
*****************************************/
function LooperDG (i) {	setTimeout(function () { ViewDG(); LooperDG(i);	}, i); }
